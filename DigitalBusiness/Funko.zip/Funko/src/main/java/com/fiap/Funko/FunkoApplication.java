package com.fiap.Funko;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FunkoApplication {

	public static void main(String[] args) {
		SpringApplication.run(FunkoApplication.class, args);
	}

}
